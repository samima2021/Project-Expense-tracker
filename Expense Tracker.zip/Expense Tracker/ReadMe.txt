Please do the steps before running
1. Run the migrate-db.bat by double-clicking it
2. Run the run-server.bat by double-clicking it
Then
3. Open bowser and browse @ http://localhost:5000
