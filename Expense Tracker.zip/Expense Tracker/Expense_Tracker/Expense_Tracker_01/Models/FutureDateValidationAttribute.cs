﻿using System;

namespace Expense_Tracker_01.Models
{
    internal class FutureDateValidationAttribute : Attribute
    {
        public string ErrorMessage { get; set; }
    }
}